"""Loss terms of CF-CoT (Eq. 1 of the paper):

    L = L_CE^sord + L_KD + alpha * L_adapt + beta * L_CoT

- sord_targets / sord_ce      : soft ordinal targets, Eq. (6)
- kd_loss                     : standard temperature-scaled KL on final logits
- pooled_softmax / cot_loss   : stage-wise JS alignment on coarse-to-fine bins, Eq. (3)
- adapt_loss                  : adapter anchoring to teacher features, Eq. (4)
- gaussian_curriculum         : stage weights w_k(t), Eq. (5)
"""
from __future__ import annotations

import math
from typing import List, Sequence

import torch
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# Ordinal soft targets (SORD)
# --------------------------------------------------------------------------- #
def sord_targets(y: torch.Tensor, num_classes: int, lam: float = 1.0) -> torch.Tensor:
    """q_c = exp(-lam (y-c)^2) / sum_j exp(-lam (y-j)^2)."""
    classes = torch.arange(num_classes, device=y.device, dtype=torch.float32)
    d2 = (y.float().unsqueeze(1) - classes.unsqueeze(0)) ** 2
    return F.softmax(-lam * d2, dim=1)


def sord_ce(logits: torch.Tensor, y: torch.Tensor, lam: float = 1.0) -> torch.Tensor:
    q = sord_targets(y, logits.size(1), lam)
    return -(q * F.log_softmax(logits, dim=1)).sum(1).mean()


# --------------------------------------------------------------------------- #
# Vanilla KD on final logits
# --------------------------------------------------------------------------- #
def kd_loss(student_logits: torch.Tensor, teacher_logits: torch.Tensor, T: float = 4.0) -> torch.Tensor:
    p_t = F.softmax(teacher_logits / T, dim=1)
    log_p_s = F.log_softmax(student_logits / T, dim=1)
    return F.kl_div(log_p_s, p_t, reduction="batchmean") * (T * T)


# --------------------------------------------------------------------------- #
# Coarse-to-fine chain-of-thought alignment
# --------------------------------------------------------------------------- #
def pooled_softmax(logits: torch.Tensor, bins: Sequence[Sequence[int]], tau: float) -> torch.Tensor:
    """[P_k(z)]_b = sum_{c in b} softmax(z / tau)_c."""
    p = F.softmax(logits / tau, dim=1)
    return torch.stack([p[:, list(b)].sum(1) for b in bins], dim=1)


def js_divergence(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    m = 0.5 * (p + q)
    kl_pm = (p * (torch.log(p + eps) - torch.log(m + eps))).sum(1)
    kl_qm = (q * (torch.log(q + eps) - torch.log(m + eps))).sum(1)
    return (0.5 * kl_pm + 0.5 * kl_qm).mean()


def gaussian_curriculum(t: float, mus: Sequence[float] = (0.1, 0.4, 0.8), sigma: float = 0.2) -> List[float]:
    """Normalised Gaussian stage weights over training progress t in [0, 1]."""
    w = [math.exp(-((t - mu) ** 2) / (2 * sigma * sigma)) for mu in mus]
    s = sum(w)
    return [x / s for x in w]


def cot_loss(
    thoughts: Sequence[torch.Tensor],
    teacher_logits: torch.Tensor,
    bins_per_stage: Sequence[Sequence[Sequence[int]]],
    taus: Sequence[float],
    weights: Sequence[float],
) -> torch.Tensor:
    """L_CoT = sum_k w_k(t) * tau_k^2 * JS( P_k(z_k) || P_k(z^T) ).

    thoughts       : list of stage logits z_1..z_K from the frozen teacher tail
    bins_per_stage : e.g. APTOS [[ [0,1],[2,3,4] ], [[0],[1],[2],[3,4]], [[0],[1],[2],[3],[4]]]
    taus           : e.g. (2, 3, 4)
    weights        : w_k(t) from gaussian_curriculum
    """
    loss = teacher_logits.new_zeros(())
    for z_k, bins, tau, w in zip(thoughts, bins_per_stage, taus, weights):
        p_s = pooled_softmax(z_k, bins, tau)
        p_t = pooled_softmax(teacher_logits.detach(), bins, tau)
        loss = loss + w * (tau * tau) * js_divergence(p_s, p_t)
    return loss


# --------------------------------------------------------------------------- #
# Adapter anchoring
# --------------------------------------------------------------------------- #
def adapt_loss(adapted: Sequence[torch.Tensor], teacher_feats: Sequence[torch.Tensor]) -> torch.Tensor:
    """L_adapt = sum_k || phi_k(f_k^S) - f_k^T ||_2^2  (mean over elements)."""
    loss = adapted[0].new_zeros(())
    for a, f in zip(adapted, teacher_feats):
        loss = loss + F.mse_loss(a, f.detach())
    return loss
