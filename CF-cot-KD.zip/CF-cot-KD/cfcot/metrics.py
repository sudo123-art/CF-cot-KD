"""OA, mean per-class accuracy, macro-F1, QWK and MAE (Sec. 4.1.2)."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import cohen_kappa_score, f1_score, recall_score


def evaluate_predictions(y_true, y_pred, num_classes: int) -> dict:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    labels = list(range(num_classes))
    return {
        "OA": float((y_true == y_pred).mean() * 100),
        "mAcc": float(recall_score(y_true, y_pred, labels=labels, average="macro", zero_division=0) * 100),
        "F1": float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0) * 100),
        "QWK": float(cohen_kappa_score(y_true, y_pred, weights="quadratic", labels=labels)),
        "MAE": float(np.abs(y_true - y_pred).mean()),
    }


def coarse_accuracy(y_true, y_pred, bins) -> float:
    """Accuracy after mapping fine grades to coarse bins (used for Fig. 3c)."""
    lut = {}
    for b_idx, b in enumerate(bins):
        for c in b:
            lut[c] = b_idx
    yt = np.vectorize(lut.get)(np.asarray(y_true))
    yp = np.vectorize(lut.get)(np.asarray(y_pred))
    return float((yt == yp).mean() * 100)
