"""ResNet teacher/student wrappers exposing stage features, plus the 1x1 adapters
that route student intermediate features into the frozen teacher tail (Eq. 2).

Stage k of torchvision ResNet == layer{k}. Channel widths:
    ResNet-18 : 64, 128, 256, 512
    ResNet-50 : 256, 512, 1024, 2048
"""
from __future__ import annotations

from typing import List, Tuple

import torch
import torch.nn as nn
import torchvision


class StagedResNet(nn.Module):
    """Wrap a torchvision ResNet so that forward returns (logits, [f1, f2, f3, f4])."""

    def __init__(self, arch: str, num_classes: int, pretrained: bool = True):
        super().__init__()
        weights = "IMAGENET1K_V1" if pretrained else None
        net = getattr(torchvision.models, arch)(weights=weights)
        self.stem = nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool)
        self.stages = nn.ModuleList([net.layer1, net.layer2, net.layer3, net.layer4])
        self.pool = net.avgpool
        self.head = nn.Linear(net.fc.in_features, num_classes)
        self.widths = [m[-1].conv1.in_channels if hasattr(m[-1], "conv3") else m[-1].conv1.in_channels
                       for m in self.stages]
        # output channels of each stage
        self.out_channels = []
        for m in self.stages:
            last = m[-1]
            self.out_channels.append(last.conv3.out_channels if hasattr(last, "conv3") else last.conv2.out_channels)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        x = self.stem(x)
        feats = []
        for stage in self.stages:
            x = stage(x)
            feats.append(x)
        logits = self.head(torch.flatten(self.pool(x), 1))
        return logits, feats

    def tail_from(self, feat: torch.Tensor, k: int) -> torch.Tensor:
        """Run stages k+1..4 and the head on a stage-k feature (1-indexed k)."""
        x = feat
        for stage in self.stages[k:]:
            x = stage(x)
        return self.head(torch.flatten(self.pool(x), 1))


class Adapters(nn.Module):
    """1x1 conv adapters phi_k lifting student stage-k features to teacher width, k = 1..3."""

    def __init__(self, student_channels: List[int], teacher_channels: List[int], num_stages: int = 3):
        super().__init__()
        self.adapters = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(student_channels[k], teacher_channels[k], kernel_size=1, bias=False),
                nn.BatchNorm2d(teacher_channels[k]),
            )
            for k in range(num_stages)
        ])

    def forward(self, student_feats: List[torch.Tensor]) -> List[torch.Tensor]:
        return [phi(f) for phi, f in zip(self.adapters, student_feats)]


@torch.no_grad()
def freeze(module: nn.Module) -> nn.Module:
    for p in module.parameters():
        p.requires_grad_(False)
    return module.eval()


def build_thoughts(teacher: StagedResNet, adapted: List[torch.Tensor]) -> List[torch.Tensor]:
    """z_k = g_T( T_4 o ... o T_{k+1} ( phi_k(f_k^S) ) ), k = 1..3.

    The teacher is frozen but gradients flow through its tail to the adapters
    and the student (the teacher parameters themselves do not update).
    """
    return [teacher.tail_from(a, k + 1) for k, a in enumerate(adapted)]
