"""Datasets for APTOS 2019 and Adience (RSSI-free image folder style)."""
from __future__ import annotations

import os
from typing import Callable, Optional

import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms


def build_transforms(train: bool, size: int = 224):
    norm = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    if train:
        return transforms.Compose([
            transforms.RandomResizedCrop(size, scale=(0.8, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(15),
            transforms.ColorJitter(0.2, 0.2, 0.2, 0.05),
            transforms.ToTensor(), norm,
        ])
    return transforms.Compose([
        transforms.Resize(int(size * 1.14)), transforms.CenterCrop(size),
        transforms.ToTensor(), norm,
    ])


class CSVImageDataset(Dataset):
    """Generic (path, label) dataset driven by a CSV with columns `path,label`."""

    def __init__(self, csv_path: str, root: str, train: bool, transform: Optional[Callable] = None):
        self.df = pd.read_csv(csv_path)
        self.root = root
        self.transform = transform or build_transforms(train)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        row = self.df.iloc[i]
        img = Image.open(os.path.join(self.root, row["path"])).convert("RGB")
        return self.transform(img), int(row["label"])
