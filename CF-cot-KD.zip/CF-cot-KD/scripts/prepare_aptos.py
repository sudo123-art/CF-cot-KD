"""Create the grade-stratified 2,928 / 734 train-validation split used in the paper.

Usage:
    python scripts/prepare_aptos.py --csv data/aptos/train.csv --out data/aptos --seed 42
"""
import argparse
import os

import pandas as pd
from sklearn.model_selection import train_test_split

p = argparse.ArgumentParser()
p.add_argument("--csv", required=True, help="official APTOS train.csv (id_code,diagnosis)")
p.add_argument("--out", required=True)
p.add_argument("--seed", type=int, default=42)
p.add_argument("--val_size", type=int, default=734)
args = p.parse_args()

df = pd.read_csv(args.csv)
df["path"] = df["id_code"].astype(str) + ".png"
df["label"] = df["diagnosis"].astype(int)
train, val = train_test_split(df, test_size=args.val_size, stratify=df["label"], random_state=args.seed)
os.makedirs(args.out, exist_ok=True)
train[["path", "label"]].to_csv(os.path.join(args.out, f"split_seed{args.seed}_train.csv"), index=False)
val[["path", "label"]].to_csv(os.path.join(args.out, f"split_seed{args.seed}_val.csv"), index=False)
print(f"train {len(train)}  val {len(val)}")
print(train["label"].value_counts().sort_index().to_dict(), val["label"].value_counts().sort_index().to_dict())
