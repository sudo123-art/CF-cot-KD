# Data layout

This directory is git-ignored except for this file. Expected layout:

```
data/
  aptos/
    train_images/            # official APTOS 2019 PNGs
    train.csv                # official id_code,diagnosis
    split_seed42.csv         # produced by scripts/prepare_aptos.py
  adience/
    aligned/                 # aligned faces
    fold_0_data.txt ... fold_4_data.txt   # official fold files
```

APTOS 2019: https://www.kaggle.com/c/aptos2019-blindness-detection
Adience:    https://talhassner.github.io/home/projects/Adience/Adience-data.html
